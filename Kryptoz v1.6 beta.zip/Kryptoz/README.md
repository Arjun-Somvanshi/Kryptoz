# Python-chat-application-with-encryption
A simple python chat application which includes the encryption of messages
